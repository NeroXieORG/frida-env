// // 1. ptrace(PT_DENY_ATTACH)
// var ptrace = Module.findGlobalExportByName("ptrace");
// if (ptrace) {
//     Interceptor.replace(ptrace, new NativeCallback(function () {
//         console.log("[*] ptrace bypassed");
//         return 0;
//     }, 'int', ['int', 'int', 'pointer', 'int']));
// }

// // 2. sysctl（反调试常用）
// var sysctl = Module.findGlobalExportByName("sysctl");
// if (sysctl) {
//     Interceptor.replace(sysctl, new NativeCallback(function () {
//         console.log("[*] sysctl bypassed");
//         return 0;
//     }, 'int', ['pointer', 'uint', 'pointer', 'pointer', 'pointer', 'uint']));
// }

// // 3. getppid / isatty（简单检测）
// ['getppid', 'isatty'].forEach(function (name) {
//     var f = Module.findGlobalExportByName(name);
//     if (f) {
//         Interceptor.replace(f, new NativeCallback(function () {
//             return 1;
//         }, 'int', []));
//     }
// });

// // 4. 防止直接 exit()
// ['exit', '_exit', 'abort'].forEach(function (name) {
//     var f = Module.findGlobalExportByName(name);
//     if (f) {
//         Interceptor.attach(f, {
//             onEnter: function () {
//                 console.log("[!] exit blocked:", name);
//                 Thread.sleep(1);
//             }
//         });
//     }
// });

// console.log("[*] anti-anti-debug loaded");
