
// import { class_copyPropertyList, property_getName, property_getAttributes, free } from './runtime';

// function getClassPropertyList(className) {
//     const targetClass = ObjC.classes[className];
//     if (!targetClass) {
//         console.log(`Class[${className}] not found`);
//         return [];
//     }

//     // 获取属性列表
//     let outCount = Memory.alloc(Process.pointerSize);
//     const propertyList = class_copyPropertyList(targetClass.handle, outCount);

//     //
//     const properties = [];
//     for (let i = 0; i < outCount.readUInt(); i++) {
//         const propertyPtr = propertyList.add(i * Process.pointerSize).readPointer();
//         const namePtr = property_getName(propertyPtr);
//         const name = namePtr.readCString();
//         const attributesPtr = property_getAttributes(propertyPtr);
//         const attributes = attributesPtr.readCString();
//         properties.push({ name, attributes });
//     }

//     // 释放内存
//     free(propertyList);

//     return properties;
// }

// const getPropertyListFromClass = (className) => {
// }

// const getMethodListFromClass = (className) => {
// }

// export {
//     getClassPropertyList,
// }




// /**
//  *function dumpIvarsByClassNameRuntime(className) {
//     if (!ObjC.classes[className]) {
//         console.log(`[-] Class ${className} not found`);
//         return;
//     }

//     // objc_getClass
//     const objc_getClass = new NativeFunction(
//         Module.findGlobalExportByName("objc_getClass"),
//         'pointer',
//         ['pointer']
//     );

//     // class_copyIvarList
//     const class_copyIvarList = new NativeFunction(
//         Module.findGlobalExportByName("class_copyIvarList"),
//         'pointer',
//         ['pointer', 'pointer']
//     );

//     const ivar_getName = new NativeFunction(
//         Module.findGlobalExportByName("ivar_getName"),
//         'pointer',
//         ['pointer']
//     );

//     const ivar_getTypeEncoding = new NativeFunction(
//         Module.findGlobalExportByName("ivar_getTypeEncoding"),
//         'pointer',
//         ['pointer']
//     );

//     const objc_getClassPtr = objc_getClass(Memory.allocUtf8String(className));
//     const outCount = Memory.alloc(Process.pointerSize);

//     const ivarListPtr = class_copyIvarList(objc_getClassPtr, outCount);
//     const count = outCount.readUInt();

//     console.log(`\n[IVARS] ${className} (${count})`);

//     for (let i = 0; i < count; i++) {

//         const ptrAddress = ivarListPtr.add(i * Process.pointerSize);

//         // 安全读取 Ivar 指针
//         const ivarPtr = ptrAddress.readPointer();

//         // 先拿 char* 指针
//         const namePtr = ivar_getName(ivarPtr);
//         const typePtr = ivar_getTypeEncoding(ivarPtr);

//         // 读取字符串
//         const name = namePtr.readCString();   // <-- 这里用 readCString 替代 Memory.readUtf8String
//         const type = typePtr.readCString();
//         console.log(`  ${name} (${type})`);
//     }
// }

//  */