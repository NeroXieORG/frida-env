const hook = (name) => {
    const f = Module.findGlobalExportByName(name);
    if (!f) return;

    console.log(`[*] hooking: ${name}`);

    Interceptor.attach(f, {
        onEnter(args) {
            console.log(`[!] CALL: ${name}`);

            if (name === "kill") {
                console.log(`kill pid = ${args[0].toInt32()} sig = ${args[1].toInt32()}`);
            }
        }
    });
};

[
    "exit",
    "_exit",
    "abort",
    "kill",
    "raise",
    "pthread_kill",
    "syscall"
].forEach(hook);

console.log("[*] death probe loaded");

/**
 * Spawn 模式进行砸壳失败时，碰到
 * 
 * Spawned `xxxx`. Resuming main thread!                    
 * [iPhone::xxxx ]-> Process terminated
 * 
 * 当所有 libc 级函数都 hook 了
 * exit / _exit / abort / kill / raise / pthread_kill / syscall 一个都没触发
 * 进程在 resume 后瞬间死亡
 * 
 * 有可能这个 App 使用的是 系统调用指令级反调试 完全绕过 libc、绕过 Frida JS
 */